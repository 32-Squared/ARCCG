/**
 * engine.test.mjs — Node.js test suite (no test framework needed)
 * Run with: node engine.test.mjs
 */

import { readFileSync } from 'fs';
import { createEngine } from './engine.js';

const manifest = JSON.parse(readFileSync('./card_manifest.json', 'utf8'));
const engine   = createEngine(manifest.cards);

let passed = 0, failed = 0;

function test(name, fn) {
  try {
    fn();
    console.log(`  ✓ ${name}`);
    passed++;
  } catch (e) {
    console.error(`  ✗ ${name}\n      ${e.message}`);
    failed++;
  }
}
function assert(cond, msg) { if (!cond) throw new Error(msg || 'Assertion failed'); }
function eq(a, b) { assert(JSON.stringify(a)===JSON.stringify(b), `Expected ${JSON.stringify(b)}, got ${JSON.stringify(a)}`); }

// ── Sample decks (minimal legal) ─────────────────────────────────────────────
const HOLLOWBACK = 1, ROLLING_THUNDER = 4, TORQUED_HOLLOWBACK = 11;
const TRACTION_CONTROL = 131, AERO_PACKAGE = 133, RACING_SLICKS = 161, JUMP_JETS = 157;
const SMOOTH_DRIVING = 212, CORNERING = 223, DRIFTING = 219, PEDAL_TO_METAL = 240;
const HYDROGLIDE = 115, ANTI_GRAV = 124, SOUND_BUFFER = 120;
const ROCKSLIDE = 175, BAT_SWARM = 176, KAMIKAZE_SEMIS = 180;
const TECHNETIUM = 50, VECTRA_TECHNETIUM = 60;
const WRECKING_BALLS = 181, PROTO_SHARKS = 184;

// Minimal 7-card deck for p1 — 3 vehicles + fills
const p1Deck = engine.shuffle([
  // Vehicles (max 1 each)
  HOLLOWBACK, ROLLING_THUNDER, TORQUED_HOLLOWBACK,
  // Mods (max 3 each)
  TRACTION_CONTROL, TRACTION_CONTROL, TRACTION_CONTROL,
  AERO_PACKAGE, AERO_PACKAGE, AERO_PACKAGE,
  RACING_SLICKS, RACING_SLICKS, RACING_SLICKS,
  // Shifts (max 3 each)
  SMOOTH_DRIVING, SMOOTH_DRIVING, SMOOTH_DRIVING,
  CORNERING, CORNERING, CORNERING,
  DRIFTING, DRIFTING, DRIFTING,
  PEDAL_TO_METAL, PEDAL_TO_METAL, PEDAL_TO_METAL,
  // Accelechargers (max 1 each)
  HYDROGLIDE, ANTI_GRAV, SOUND_BUFFER,
  // Hazards (max 3 each)
  ROCKSLIDE, ROCKSLIDE, ROCKSLIDE,
  BAT_SWARM, BAT_SWARM, BAT_SWARM,
  KAMIKAZE_SEMIS, KAMIKAZE_SEMIS, KAMIKAZE_SEMIS,
]);

// p2 uses same set
const p2Deck = engine.shuffle([...p1Deck]);

// 4 legal realm IDs
const REALMS = [82, 87, 91, 92]; // Canyon, Wind, Solar, Cliffside

// ── Tests ─────────────────────────────────────────────────────────────────────
console.log('\n── Deck Validation ──');
test('valid deck passes', () => {
  const errs = engine.validateDeck(p1Deck);
  eq(errs, []);
});
test('over-80 deck fails', () => {
  const bigDeck = Array(81).fill(SMOOTH_DRIVING);
  const errs = engine.validateDeck(bigDeck);
  assert(errs.some(e => e.includes('80')));
});
test('duplicate vehicle fails', () => {
  const errs = engine.validateDeck([HOLLOWBACK, HOLLOWBACK, SMOOTH_DRIVING]);
  assert(errs.some(e => e.includes('max 1')));
});
test('4x shift fails', () => {
  const errs = engine.validateDeck([SMOOTH_DRIVING, SMOOTH_DRIVING, SMOOTH_DRIVING, SMOOTH_DRIVING, HOLLOWBACK]);
  assert(errs.some(e => e.includes('max 3')));
});

console.log('\n── Game Creation ──');
let state = engine.createGame({
  realmIds: REALMS, p1Deck, p2Deck,
  p1Name: 'Alice', p2Name: 'Bob', firstPlayer: 1
});

test('game state created', () => {
  assert(state.turn === 1);
  assert(state.active_player === 1);
  assert(state.phase === 'draw');
  assert(state.realms.length === 4);
});
test('players initialised', () => {
  assert(state.players[1].name === 'Alice');
  assert(state.players[2].name === 'Bob');
  assert(state.players[1].draw_pile.length === p1Deck.length);
});

console.log('\n── Opening Hands ──');
test('draw opening hand p1', () => {
  const r = engine.drawOpeningHand(state, 1);
  assert(r.ok);
  state = r.state;
  assert(state.players[1].hand.length === 7, `hand size ${state.players[1].hand.length}`);
  // Must contain at least 1 vehicle
  const hasVehicle = state.players[1].hand.some(id => {
    const c = manifest.cards.find(c=>c.id===id);
    return c?.type === 'Vehicle';
  });
  assert(hasVehicle, 'Opening hand must contain a vehicle');
});
test('draw opening hand p2', () => {
  const r = engine.drawOpeningHand(state, 2);
  assert(r.ok);
  state = r.state;
  assert(state.players[2].hand.length === 7);
});

console.log('\n── Turn Sequence: P1 Turn 1 ──');
test('beginTurn', () => {
  const r = engine.beginTurn(state);
  assert(r.ok);
  state = r.state;
  assert(state.phase === 'draw');
});
test('phaseDraw', () => {
  const r = engine.phaseDraw(state);
  assert(r.ok);
  state = r.state;
  assert(state.phase === 'advance');
  assert(state.players[1].hand.length === 8);
});
test('advanceEligible (nothing advances turn 1)', () => {
  const r = engine.advanceEligible(state);
  assert(r.ok);
  state = r.state;
  assert(state.phase === 'play_vehicle');
});

// Put a vehicle in hand to play
test('playVehicle from hand', () => {
  // Ensure Hollowback is in hand (force it for test)
  const p1 = state.players[1];
  if (!p1.hand.includes(HOLLOWBACK)) {
    p1.hand.push(HOLLOWBACK);
    const idx = p1.draw_pile.indexOf(HOLLOWBACK);
    if (idx >= 0) p1.draw_pile.splice(idx, 1);
  }
  const r = engine.playVehicle(state, 1, HOLLOWBACK);
  assert(r.ok, r.error);
  state = r.state;
  assert(state.players[1].vehicles.length === 1);
  assert(state.players[1].vehicles[0].realm_position === 1);
  assert(!state.players[1].hand.includes(HOLLOWBACK));
});

test('cannot play second vehicle same turn', () => {
  // Ensure Rolling Thunder in hand
  if (!state.players[1].hand.includes(ROLLING_THUNDER)) {
    state.players[1].hand.push(ROLLING_THUNDER);
  }
  const r = engine.playVehicle(state, 1, ROLLING_THUNDER);
  assert(!r.ok, 'Should have failed — already played vehicle');
  assert(r.error.includes('Already played'));
});

test('tuneUp', () => {
  // First skip to action phase via skipPlayVehicle... 
  // We already played, so move to tune_up
  state.phase = 'tune_up';
  const r = engine.tuneUp(state);
  assert(r.ok, r.error);
  state = r.state;
  assert(state.phase === 'action');
});

test('team bonus APs: 0 teams initially', () => {
  // 1 vehicle but no team bonus until 2+ vehicles of same team
  const aps = engine.calcTeamBonusAPs(state, 1);
  // Hollowback is Metal Maniacs, only 1 vehicle => no bonus
  eq(aps, 0);
});

console.log('\n── AP Spending ──');
test('equipShift on vehicle', () => {
  const p1 = state.players[1];
  if (!p1.hand.includes(SMOOTH_DRIVING)) p1.hand.push(SMOOTH_DRIVING);
  const initAPs = p1.aps_remaining;
  const r = engine.equipShift(state, 1, SMOOTH_DRIVING, 0);
  assert(r.ok, r.error);
  state = r.state;
  const c = manifest.cards.find(c=>c.id===SMOOTH_DRIVING);
  eq(state.players[1].aps_remaining, initAPs - c.ap_cost);
  eq(state.players[1].vehicles[0].equipped_shift, SMOOTH_DRIVING);
});

test('insufficient APs fails', () => {
  state.players[1].aps_remaining = 0;
  if (!state.players[1].hand.includes(CORNERING)) state.players[1].hand.push(CORNERING);
  const r = engine.equipShift(state, 1, CORNERING, 0);
  assert(!r.ok);
  assert(r.error.includes('APs'));
});

test('equipMod Street mod on Street vehicle (Aero Package on Hollowback)', () => {
  state.players[1].aps_remaining = 3;
  const p1 = state.players[1];
  if (!p1.hand.includes(AERO_PACKAGE)) p1.hand.push(AERO_PACKAGE);
  const r = engine.equipMod(state, 1, AERO_PACKAGE, 0);
  assert(r.ok, r.error);
  state = r.state;
  assert(state.players[1].vehicles[0].equipped_mods.includes(AERO_PACKAGE));
});

test('equipMod Race mod on Street vehicle fails (modability mismatch)', () => {
  state.players[1].aps_remaining = 3;
  const p1 = state.players[1];
  if (!p1.hand.includes(TRACTION_CONTROL)) p1.hand.push(TRACTION_CONTROL);
  const r = engine.equipMod(state, 1, TRACTION_CONTROL, 0);
  assert(!r.ok, 'Should fail — Race mod on Street vehicle');
  assert(r.error.includes('Modability'));
});

console.log('\n── SPP Calculation ──');
test('calcSPP base vehicle', () => {
  // Hollowback base S=3,P=3,Pf=2 + Smooth Driving shift S=0,P=1,Pf=0 + Aero Package mod S=2,P=0,Pf=1
  const spp = engine.calcSPP(state, 1, 0);
  eq(spp.speed,       5); // 3+0+2
  eq(spp.power,       4); // 3+1+0
  eq(spp.performance, 3); // 2+0+1
});

test('terrain bonus adds +1 to all SPP values', () => {
  state.players[1].vehicles[0].terrain_bonus = true;
  const spp = engine.calcSPP(state, 1, 0);
  eq(spp.speed, 6); eq(spp.power, 5); eq(spp.performance, 4);
  state.players[1].vehicles[0].terrain_bonus = false;
});

console.log('\n── Hazards ──');
test('playHazard reduces shift SPP and junks it', () => {
  // Put a vehicle + shift in p2's stack
  state.players[2].vehicles.push({
    card_id: ROLLING_THUNDER, realm_position: 1,
    equipped_mods: [], equipped_shift: SMOOTH_DRIVING, equipped_ac: null,
    tokens: {}, terrain_bonus: false, hack_mimic_team: null
  });
  state.players[2].hand.push(SMOOTH_DRIVING);
  // Give p1 a hazard and enough APs
  state.players[1].aps_remaining = 3;
  state.players[1].hand.push(BAT_SWARM); // Bat Swarm: 0,-1,-1
  // Target p2 vehicle 0, shift SMOOTH_DRIVING (0,1,0 → 0,0,-1 → junked on power)
  const r = engine.playHazard(state, 1, BAT_SWARM, 0, SMOOTH_DRIVING);
  assert(r.ok, r.error);
  state = r.state;
  assert(state.players[2].vehicles[0].equipped_shift === null, 'Shift should be junked');
  assert(state.players[2].junk_pile.includes(SMOOTH_DRIVING), 'Shift in junk');
});

test('Wrecking Balls sets no_mods flag', () => {
  state.players[1].hand.push(WRECKING_BALLS);
  state.players[1].aps_remaining = 3;
  const r = engine.playHazard(state, 1, WRECKING_BALLS, 0);
  assert(r.ok, r.error);
  state = r.state;
  assert(state.players[2].no_mods_next_turn === true);
});

console.log('\n── Hand Limit / End Turn ──');
test('endTurn discards to hand limit (7)', () => {
  state.phase = 'action';
  while (state.players[1].hand.length < 10) state.players[1].hand.push(SMOOTH_DRIVING);
  const r = engine.endTurn(state, 1);
  assert(r.ok, r.error);
  state = r.state;
  assert(state.players[1].hand.length <= 7, `hand was ${state.players[1].hand.length}`);
  assert(state.active_player === 2, 'Should be p2 turn');
  assert(state.turn === 2);
});

console.log('\n── Hand Limit Abilities ──');
test('Technetium raises hand limit to 8', () => {
  // Put Technetium vehicle in play for p1
  state.players[1].vehicles.push({
    card_id: TECHNETIUM, realm_position: 1,
    equipped_mods: [], equipped_shift: null, equipped_ac: null,
    tokens: {}, terrain_bonus: false, hack_mimic_team: null
  });
  // Simulate on-play trigger manually
  state.players[1].hand_limit = 8;
  eq(state.players[1].hand_limit, 8);
});

console.log('\n── Encode/Decode ──');
test('state round-trips through encode/decode', () => {
  const encoded = engine.encodeState(state);
  assert(typeof encoded === 'string' && encoded.length > 0);
  const decoded = engine.decodeState(encoded);
  eq(decoded.turn, state.turn);
  eq(decoded.active_player, state.active_player);
  eq(decoded.realms, state.realms);
  eq(decoded.players[1].vehicles.length, state.players[1].vehicles.length);
});

console.log('\n── Salvage Abilities ──');
test('salvageMod retrieves mod from junk', () => {
  state.players[1].junk_pile.push(TRACTION_CONTROL);
  const handBefore = state.players[1].hand.length;
  const r = engine.salvageMod(state, 1, TRACTION_CONTROL);
  assert(r.ok, r.error);
  state = r.state;
  assert(state.players[1].hand.length === handBefore + 1);
  assert(state.players[1].hand.includes(TRACTION_CONTROL));
});
test('salvageMod fails if not in junk', () => {
  const r = engine.salvageMod(state, 1, 999);
  assert(!r.ok);
});

console.log('\n── Win Condition ──');
test('3 finished vehicles triggers game over', () => {
  // Build a clean state with 3 pre-finished vehicles
  const s = {
    version:1, created:'', turn:5, phase:'advance', active_player:1, winner:null,
    realms:REALMS, restrictions:{ no_shifts_realm_idx:null },
    players:{
      1:{ name:'Alice', draw_pile:[], hand:[], junk_pile:[],
          vehicles:[
            { card_id:1,  realm_position:5, equipped_mods:[], equipped_shift:null, equipped_ac:null, tokens:{}, terrain_bonus:false, hack_mimic_team:null },
            { card_id:4,  realm_position:5, equipped_mods:[], equipped_shift:null, equipped_ac:null, tokens:{}, terrain_bonus:false, hack_mimic_team:null },
            { card_id:11, realm_position:5, equipped_mods:[], equipped_shift:null, equipped_ac:null, tokens:{}, terrain_bonus:false, hack_mimic_team:null },
          ],
          played_vehicle_this_turn:false, aps_remaining:3, hand_limit:7,
          no_mods_next_turn:false, no_shifts_next_turn:false, limited_aps_next_turn:null },
      2:{ name:'Bob', draw_pile:[], hand:[], junk_pile:[], vehicles:[],
          played_vehicle_this_turn:false, aps_remaining:3, hand_limit:7,
          no_mods_next_turn:false, no_shifts_next_turn:false, limited_aps_next_turn:null }
    },
    pending_effects:[], log:[]
  };
  const r = engine.advanceEligible(s);
  assert(r.ok);
  assert(r.state.winner === 1, `winner was ${r.state.winner}`);
  assert(r.state.phase === 'game_over');
});

// ── Summary ──────────────────────────────────────────────────────────────────
console.log(`\n${'─'.repeat(40)}`);
console.log(`Tests: ${passed + failed}  ✓ ${passed}  ✗ ${failed}`);
if (failed > 0) process.exit(1);
